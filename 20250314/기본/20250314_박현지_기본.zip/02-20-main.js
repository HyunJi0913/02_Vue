import { add } from './modules/02-19-module.js';
console.log(add(4));
